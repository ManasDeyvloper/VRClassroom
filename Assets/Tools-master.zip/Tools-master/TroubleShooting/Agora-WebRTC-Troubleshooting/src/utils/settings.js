export const profileArray = [
  {resolution: '120p_1', width: 160, height: 120},
  {resolution: '180p_1', width: 320, height: 180},
  {resolution: '240P_1', width: 320, height: 240},
  {resolution: '360p_1', width: 640, height: 360},
  {resolution: '480p_1', width: 640, height: 480},
  {resolution: '720p_1', width: 1280, height: 720},
  {resolution: '1080p_1', width: 1920, height: 1080}
]

export const APP_ID = ''  // input your app id here