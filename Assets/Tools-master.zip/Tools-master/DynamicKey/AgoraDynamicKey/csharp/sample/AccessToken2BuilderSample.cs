// The samples of RtcTokenBuilder2 refer to the functions in test/AgoraIO.Tests/AccessToken2Test.cs : 
// RtcToken_buildTokenWithUid1
// RtcToken_buildTokenWithUid2
// RtcToken_buildTokenWithUserAccount1
// RtcToken_buildTokenWithUserAccount2

// The samples of RtmTokenBuilder2 refer to the function in test/AgoraIO.Tests/AccessToken2Test.cs : 
// RtmToken_buildToken

// The samples of ChatTokenBuilder2 refer to the functions in test/AgoraIO.Tests/AccessToken2Test.cs : 
// ChatToken_buildUserToken
// ChatToken_buildAppToken

// The samples of FpaTokenBuilder2 refer to the function in test/AgoraIO.Tests/AccessToken2Test.cs : 
// FpaToken_buildToken

// The samples of EducationTokenBuilder2 refer to the functions in test/AgoraIO.Tests/AccessToken2Test.cs : 
// EducationToken_buildRoomUserToken
// EducationToken_buildUserToken
// EducationToken_buildAppToken
