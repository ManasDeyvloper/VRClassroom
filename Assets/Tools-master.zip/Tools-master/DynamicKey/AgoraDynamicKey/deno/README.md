# Authenticate Users with a token

To enhance communication security, Agora uses tokens to authenticate users before they access the Agora service, or joining an RTC channel.

## Code structure

Under the `nodejs` directory:

* `/src/` contains the source code for generating a token, where `RtcTokenBuilder.js` is used for generating an RTC token, and `RtmTokenBuilder.js` is used for generating an RTM token.
* `/sample/` contains the sample code for generating a token, where `RtcTokenBuilderSample.js` is used for generating an RTC token, and `RtmTokenBuilderSample.js` is used for generating an RTM token.

## Generate a token with the sample code

This section takes `RtcTokenBuilderSample.js` as an example to show how to generate a token with the sample code.

Before proceeding, ensure that you have installed the LTS version of Deno.

1. Download or clone the [Tools](https://github.com/AgoraIO/Tools) repository.

2. Open the `DynamicKey/AgoraDynamicKey/nodejs/sample/RtcTokenBuilderSample.js` file, replace the value of `appID`, `appCertificate`, `channelName`, and `uid` with your own, and comment out the code snippets of `buildTokenWithUserAccount`.

3. Open your Terminal, navigate to the same directory that holds `RtcTokenBuilderSample.js`, and run the following command. The token is generated and printed in your Terminal window.

   ```
   deno run RtcTokenBuilderSample.js
   ```

## Reference

For a complete authentication flow between the app server and app client, see [Authenticate Your Users with Tokens]().
