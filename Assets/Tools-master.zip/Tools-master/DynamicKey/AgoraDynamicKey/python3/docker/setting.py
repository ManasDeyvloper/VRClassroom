# -*- coding: utf-8 -*-
__copyright__ = "Copyright (c) 2014-2017 Agora.io, Inc."


class BaseConfig(object):
    ENV = 'production'
    DEBUG = False
    TESTING = False

    APP_ID = ''
    APP_CERTIFICATE = ''

